/**
 * Advanced Code Secure Pro - UI Controller
 */

(function () {
    const init = () => {
        // DOM Elements - Tabs
        const tabBtns = document.querySelectorAll('.tab-btn');
        const encryptView = document.getElementById('encrypt-view');
        const decryptView = document.getElementById('decrypt-view');

        // DOM Elements - Encrypt
        const sourceInput = document.getElementById('source-input');
        const masterKey = document.getElementById('master-key');
        const domainLock = document.getElementById('domain-lock');
        const outputScreen = document.getElementById('output-screen');
        const secureBtn = document.getElementById('secure-btn');
        const detectedType = document.getElementById('detected-type');
        const sourceSize = document.getElementById('source-size');
        const copyBtn = document.getElementById('copy-btn');
        const downloadBtn = document.getElementById('download-btn');

        // DOM Elements - Decrypt
        const decInput = document.getElementById('dec-input');
        const decKey = document.getElementById('dec-key');
        const decOutput = document.getElementById('dec-output');
        const recoverBtn = document.getElementById('recover-btn');

        const statusMsg = document.getElementById('status-msg');

        // Tab Switching Logic
        tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                tabBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                const tab = btn.dataset.tab;
                if (tab === 'encrypt') {
                    encryptView.classList.remove('hidden');
                    decryptView.classList.add('hidden');
                } else {
                    encryptView.classList.add('hidden');
                    decryptView.classList.remove('hidden');
                }
            });
        });

        // Auto-detection and Stats
        sourceInput.addEventListener('input', () => {
            const val = sourceInput.value.trim();
            const size = new Blob([sourceInput.value]).size;
            sourceSize.textContent = `${size} bytes`;

            if (!val) {
                detectedType.textContent = "DETECTING...";
                return;
            }

            const startsWithTag = /^\s*<([a-z!/])/i.test(val);
            const hasJsKeywords = /(console\.|document\.|function\s|const\s|let\s|var\s|=>|\balert\(|\bevent\.)/.test(val);
            const hasCssMarkers = /[{}]/.test(val) && (/[a-zA-Z0-9-]+\s*:\s*[^;]+/.test(val));
            const hasCssSelectors = /^\s*([.#a-z-_][^{]*)\{/i.test(val);

            if (startsWithTag) {
                detectedType.textContent = "HTML DOCUMENT";
            } else if (hasJsKeywords) {
                detectedType.textContent = "JAVASCRIPT";
            } else if (hasCssMarkers || hasCssSelectors) {
                detectedType.textContent = "CSS STYLESHEET";
            } else {
                detectedType.textContent = "PLAIN TEXT";
            }
        });

        // Full-screen Toggle Feature
        const fullscreenBtn = document.getElementById('fullscreen-btn');
        const fullscreenCloseBtn = document.getElementById('fullscreen-close-btn');
        const outputSection = document.querySelector('.output-section');

        function toggleFullscreen(forceOff = false) {
            const isFull = outputSection.classList.contains('full-screen');
            if (forceOff || isFull) {
                outputSection.classList.remove('full-screen');
                document.body.classList.remove('has-fullscreen');
                fullscreenBtn.classList.remove('active');
                fullscreenCloseBtn.classList.add('hidden');
                document.body.style.overflow = '';
                if (isFull) updateStatus("FULL SCREEN MODE DISABLED");
            } else {
                outputSection.classList.add('full-screen');
                document.body.classList.add('has-fullscreen');
                fullscreenBtn.classList.add('active');
                fullscreenCloseBtn.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
                updateStatus("FULL SCREEN MODE ENABLED");
            }
        }

        fullscreenBtn.addEventListener('click', () => toggleFullscreen());
        fullscreenCloseBtn.addEventListener('click', () => toggleFullscreen(true));

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && outputSection.classList.contains('full-screen')) {
                toggleFullscreen(true);
            }
        });

        // Action Buttons
        copyBtn.addEventListener('click', () => {
            if (!outputScreen.value) return;
            navigator.clipboard.writeText(outputScreen.value);
            updateStatus("COPIED TO CLIPBOARD");
            setTimeout(() => updateStatus("READY FOR SECURITY OPS"), 2000);
        });

        downloadBtn.addEventListener('click', () => {
            const content = outputScreen.value;
            if (!content) return;

            let ext = ".html";
            let mimeType = "text/html";
            const type = detectedType.textContent;

            if (type === "JAVASCRIPT") {
                ext = ".js";
                mimeType = "application/javascript";
            } else if (type === "CSS STYLESHEET") {
                ext = ".css";
                mimeType = "text/css";
            } else if (type === "PLAIN TEXT") {
                ext = ".txt";
                mimeType = "text/plain";
            }

            const blob = new Blob([content], { type: mimeType });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `secured_file${ext}`;
            a.click();
            URL.revokeObjectURL(url);
        });

        // Encryption Logic
        secureBtn.addEventListener('click', async () => {
            const code = sourceInput.value.trim();
            const pw = masterKey.value.trim();
            const domains = domainLock.value.trim() || "*";

            if (!code) return updateStatus("ERROR: NO SOURCE CODE", true);
            if (!pw) return updateStatus("ERROR: NO MASTER KEY", true);

            try {
                updateStatus("PROCESSING PAYLOAD...");
                secureBtn.disabled = true;

                const type = detectedType.textContent;
                let finalShell;

                if (type === "CSS STYLESHEET") {
                    updateStatus("MINIFYING CSS...");
                    finalShell = Obfuscator.minifyCSS(code);
                } else {
                    updateStatus("DERIVING HARDENED KEYS (100K ITERATIONS)...");
                    const encrypted = await HardenedSecurity.encrypt(code, pw);
                    updateStatus("GENERATING POLYMORPHIC JUNK...");
                    finalShell = Obfuscator.wrap(encrypted, domains, pw, type);
                }

                outputScreen.value = finalShell;
                updateStatus("READY: PAYLOAD SECURED", false);
            } catch (e) {
                updateStatus("FATAL: ENCRYPTION FAILED", true);
                console.error(e);
            } finally {
                secureBtn.disabled = false;
            }
        });

        // Decryption Logic
        recoverBtn.addEventListener('click', async () => {
            let payload = decInput.value.trim();
            const pw = decKey.value.trim();

            if (!payload) return updateStatus("ERROR: NO PAYLOAD", true);
            if (!pw) return updateStatus("ERROR: NO PASSWORD", true);

            // AUTO-EXTRACT: If user pasted a full shell, find the _p variable
            const shellMatch = payload.match(/const\s+_p\s*=\s*"(.*?)"/s) || payload.match(/_p\s*=\s*"(.*?)"/s);
            if (shellMatch && shellMatch[1]) {
                payload = shellMatch[1];
                updateStatus("SHELL DETECTED: EXTRACTING PAYLOAD...");
            }

            try {
                updateStatus("ATTEMPTING RECOVERY...");
                recoverBtn.disabled = true;

                const decrypted = await HardenedSecurity.decrypt(payload, pw);
                decOutput.value = decrypted;

                updateStatus("SUCCESS: SOURCE RECOVERED");
            } catch (e) {
                updateStatus("FATAL: INCORRECT KEY OR TAMPERED DATA", true);
                decOutput.value = "";
            } finally {
                recoverBtn.disabled = false;
            }
        });

        function updateStatus(msg, isError = false) {
            statusMsg.textContent = msg;
            statusMsg.style.color = isError ? "var(--danger)" : "var(--text-secondary)";
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
