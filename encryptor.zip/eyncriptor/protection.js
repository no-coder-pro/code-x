/**
 * Advanced Code Secure Pro - Protection Suite
 * Aggressive anti-debugging, shortcut blocking, and environment probes.
 */

const ProtectionSuite = {
    init() {
        this.disableContext();
        this.disableShortcuts();
        this.startDebuggerTrap();
        this.checkEnvironment();
    },

    disableContext() {
        document.addEventListener('contextmenu', e => e.preventDefault());
    },

    disableShortcuts() {
        document.addEventListener('keydown', e => {
            // F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U, Ctrl+S
            const forbiddenKeys = ['F12', 'I', 'J', 'U', 'S'];
            if (
                e.key === 'F12' ||
                (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J')) ||
                (e.ctrlKey && (e.key === 'u' || e.key === 's'))
            ) {
                e.preventDefault();
                return false;
            }
        });
    },

    /**
     * Recursive debugger trap.
     * When DevTools is open, this will trigger a pause, making the site unusable.
     */
    startDebuggerTrap() {
        const trap = function () {
            try {
                (function () {
                    (function a() {
                        debugger;
                        setTimeout(a, 50);
                    })();
                })();
            } catch (e) { }
        };

        // Only start if not in local dev (simple check)
        if (window.location.protocol !== 'file:') {
            setInterval(trap, 1000);
        }
    },

    /**
     * Checks if running in a "suspicious" environment.
     */
    checkEnvironment() {
        // Anti-headless check
        if (navigator.webdriver) {
            document.body.innerHTML = '<h1>Access Denied: Environment not supported.</h1>';
            throw new Error('Headless browser detected.');
        }

        // Anti-VM check (basic heuristic)
        const canvas = document.createElement('canvas');
        const gl = canvas.getContext('webgl');
        if (gl) {
            const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
            if (debugInfo) {
                const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
                if (renderer.includes('VMware') || renderer.includes('VirtualBox') || renderer.includes('SwiftShader')) {
                    console.warn('Suspicious renderer detected');
                }
            }
        }
    }
};

if (typeof window !== 'undefined') {
    ProtectionSuite.init();
    window.ProtectionSuite = ProtectionSuite;
}
