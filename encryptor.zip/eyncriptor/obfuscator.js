/**
 * Advanced Code Secure Pro - Obfuscator & Junk Generator
 * Generates polymorphic junk code and wraps the payload in a VM-like shell.
 */

const Obfuscator = {
    /**
     * Simple CSS minifier to remove comments and whitespace.
     */
    minifyCSS(css) {
        return css
            .replace(/\/\*[\s\S]*?\*\//g, '') // Remove comments
            .replace(/\s+/g, ' ')           // Collapse whitespace
            .replace(/\s*([{}])\s*/g, '$1')  // Remove spaces around braces
            .replace(/\s*([:;])\s*/g, '$1')  // Remove spaces around colons and semicolons
            .trim();
    },

    /**
     * Generates random "Poly-Junk" code to bloat the file.
     */
    generateJunk(lines = 1000) {
        const patterns = [
            () => {
                const id = Math.random().toString(16).slice(2, 8);
                return `const _0x${id} = function(){ return ${Math.random()}; }; if(_0x${id}() > 0.5){ /* initialization */ }`;
            },
            () => `var _0x${Math.random().toString(16).slice(2, 8)} = [${Array.from({ length: 5 }, () => Math.floor(Math.random() * 100)).join(',')}];`,
            () => `[${Array.from({ length: 3 }, () => Math.floor(Math.random() * 50)).join(',')}].map(x => x * ${Math.random().toFixed(2)});`,
            () => {
                const id = Math.random().toString(16).slice(2, 8);
                return `(function(_0x${id}){ return _0x${id} * 2; })(${Math.random()});`;
            }
        ];

        let junk = "";
        for (let i = 0; i < lines; i++) {
            junk += patterns[Math.floor(Math.random() * patterns.length)]() + "\n";
        }
        return junk;
    },

    /**
     * Highly obfuscated template for the output file with Cloudflare-style challenge.
     */
    wrap(encryptedPayload, domainList = "*", masterKey = "", type = "HTML DOCUMENT") {
        if (type === "JAVASCRIPT") {
            return this.wrapJS(encryptedPayload, domainList, masterKey);
        } else if (type === "PLAIN TEXT" || type === "CSS STYLESHEET") {
            return encryptedPayload;
        }
        return this.wrapHTML(encryptedPayload, domainList, masterKey);
    },

    wrapJS(encryptedPayload, domainList, masterKey) {
        const _k = btoa(Array.from(masterKey).map(c => String.fromCharCode(c.charCodeAt(0) ^ 0x0F)).join(''));
        return `(async function() {
    const _p = "${encryptedPayload}";
    const _authorized = "${domainList}";
    const _encK = "${_k}";
    
    // Domain Lock
    const currentHost = typeof window !== 'undefined' ? window.location.hostname : "";
    if (_authorized !== "*" && _authorized !== "") {
        const allowed = _authorized.split(",").map(d => d.trim());
        if (!allowed.some(d => currentHost.includes(d))) {
            console.error("DOMAIN NOT AUTHORIZED");
            return;
        }
    }

    try {
        const _raw = atob(_encK).split('').map(c => String.fromCharCode(c.charCodeAt(0) ^ 0x0F)).join('');
        const HardenedDec = (function(){
            const IT = 100000;
            const S_SZ = 16;
            const I_SZ = 12;
            return {
                async run(base64, pw) {
                    const data = new Uint8Array(atob(base64).split("").map(c => c.charCodeAt(0)));
                    const salt = data.slice(0, S_SZ);
                    const iv = data.slice(S_SZ, S_SZ+I_SZ);
                    const encData = data.slice(S_SZ+I_SZ);
                    const enc = new TextEncoder();
                    const bKey = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveKey"]);
                    const key = await crypto.subtle.deriveKey({name:"PBKDF2",salt:salt,iterations:IT,hash:"SHA-512"},bKey,{name:"AES-GCM",length:256},false,["decrypt"]);
                    const dec = await crypto.subtle.decrypt({name:"AES-GCM",iv:iv},key,encData);
                    let s = Array.from(enc.encode(pw)).reduce((a, b) => a + b, 0);
                    const unshuffled = new Uint8Array(dec);
                    for(let i=0; i<unshuffled.length; i++) {
                        s = (s * 16807) % 2147483647;
                        unshuffled[i] = unshuffled[i] ^ (s & 0xFF);
                    }
                    return new TextDecoder().decode(unshuffled);
                }
            };
        })();

        const result = await HardenedDec.run(_p, _raw);
        eval(result);
    } catch(e) {
        console.error("ENVIRONMENT CHECK FAILED");
    }
})();`;
    },

    wrapHTML(encryptedPayload, domainList, masterKey) {
        const junkTop = this.generateJunk(300);
        const junkBottom = this.generateJunk(300);
        const _k = btoa(Array.from(masterKey).map(c => String.fromCharCode(c.charCodeAt(0) ^ 0x0F)).join(''));

        return `<!DOCTYPE html>
<html lang="en">
<head>
    <title>Encrypted Content</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style>
        body { background: #0a0a0a; color: #00f2ff; font-family: 'JetBrains Mono', monospace; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; overflow: hidden; }
        .secure-loader { text-align: center; }
        .spinner { width: 40px; height: 40px; border: 3px solid rgba(0, 242, 255, 0.1); border-top: 3px solid #00f2ff; border-radius: 50%; animation: spin 0.6s linear infinite; margin: 0 auto 20px; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .label { font-size: 12px; letter-spacing: 2px; text-transform: uppercase; opacity: 0.8; }
        #error-log { color: #ff4d4d; margin-top: 20px; display: none; font-size: 11px; }
    </style>
</head>
<body>
    <div class="secure-loader" id="loader">
        <div class="spinner"></div>
        <div class="label" id="status-label">Decrypting Environment...</div>
        <div id="error-log">ENVIRONMENT CHECK FAILED</div>
    </div>

    <script data-cfasync="false">
        ${junkTop}
        
        window.onload = async function() {
            const _p = "${encryptedPayload}";
            const _authorized = "${domainList}"; 
            const _encK = "${_k}";
            const errorLog = document.getElementById('error-log');
            const loader = document.getElementById('loader');
            const spinner = document.querySelector('.spinner');
            
            // Domain Lock Check
            const currentHost = window.location.hostname;
            if (_authorized !== "*" && _authorized !== "") {
                const allowed = _authorized.split(",").map(d => d.trim());
                if (!allowed.some(d => currentHost.includes(d))) {
                    spinner.style.display = 'none';
                    document.getElementById('status-label').textContent = 'DOMAIN NOT AUTHORIZED';
                    document.getElementById('status-label').style.color = '#ff4d4d';
                    return;
                }
            }

            try {
                const _raw = atob(_encK).split('').map(c => String.fromCharCode(c.charCodeAt(0) ^ 0x0F)).join('');
                const HardenedDec = (function(){
                    const IT = 100000;
                    const S_SZ = 16;
                    const I_SZ = 12;
                    return {
                        async run(base64, pw) {
                            const data = new Uint8Array(atob(base64).split("").map(c => c.charCodeAt(0)));
                            const salt = data.slice(0, S_SZ);
                            const iv = data.slice(S_SZ, S_SZ+I_SZ);
                            const encData = data.slice(S_SZ+I_SZ);
                            const enc = new TextEncoder();
                            const bKey = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveKey"]);
                            const key = await crypto.subtle.deriveKey({name:"PBKDF2",salt:salt,iterations:IT,hash:"SHA-512"},bKey,{name:"AES-GCM",length:256},false,["decrypt"]);
                            const dec = await crypto.subtle.decrypt({name:"AES-GCM",iv:iv},key,encData);
                            let s = Array.from(enc.encode(pw)).reduce((a, b) => a + b, 0);
                            const unshuffled = new Uint8Array(dec);
                            for(let i=0; i<unshuffled.length; i++) {
                                s = (s * 16807) % 2147483647;
                                unshuffled[i] = unshuffled[i] ^ (s & 0xFF);
                            }
                            return new TextDecoder().decode(unshuffled);
                        }
                    };
                })();

                const result = await HardenedDec.run(_p, _raw);
                document.open();
                document.write(result);
                document.close();
            } catch(e) {
                spinner.style.display = 'none';
                errorLog.style.display = 'block';
                console.error(e);
            }
        };

        ${junkBottom}
    </script>
</body>
</html>`;
    }
};

if (typeof module !== 'undefined') module.exports = Obfuscator;
if (typeof window !== 'undefined') {
    window.Obfuscator = Obfuscator;
}
